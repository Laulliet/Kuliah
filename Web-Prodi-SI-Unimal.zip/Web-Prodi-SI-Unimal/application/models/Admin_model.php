<?php 
 
class Admin_model extends CI_Model{	

	public function ambil_galeri(){
		$query=$this->db->query("SELECT * FROM galeri");
		return $query;
	}

	public function simpan($table, $data){
		return $this->db->insert($table, $data);
	}

	public function Hapus($table,$where){
		return $this->db->delete($table,$where);
	}

	public function edit_galeri($where= "") {
		$data = $this->db->query('SELECT * FROM galeri '.$where);
		return $data;
	}

	public function update_galeri($data){
        $this->db->where('id_galeri',$data['id_galeri']);
        $this->db->update('galeri',$data);
    }	

    public function ambil_kegiatan_mahasiswa(){
		$query=$this->db->query("SELECT * FROM kegiatan_mahasiswa");
		return $query;
	}

	public function edit_kegiatan_mahasiswa($where= "") {
		$data = $this->db->query('SELECT * FROM kegiatan_mahasiswa '.$where);
		return $data;
	}

	public function update_kegiatan_mahasiswa($data){
        $this->db->where('id',$data['id']);
        $this->db->update('kegiatan_mahasiswa',$data);
    }

    public function ambil_mk(){
		$query=$this->db->query("SELECT * FROM mk");
		return $query;
	}

	public function edit_mk($where= "") {
		$data = $this->db->query('SELECT * FROM mk '.$where);
		return $data;
	}

	public function update_mk($data){
        $this->db->where('id_mk',$data['id_mk']);
        $this->db->update('mk',$data);
    }

    public function ambil_dosen(){
		$query=$this->db->query("SELECT dosen.*, mk.`nama` as nama_mk FROM dosen JOIN mk ON dosen.`id_mk` = mk.`id_mk`");
		return $query;
	}		

	public function edit_dosen($where= "") {
		$data = $this->db->query('SELECT * FROM dosen '.$where);
		return $data;
	}

	public function update_dosen($data){
        $this->db->where('id_dosen',$data['id_dosen']);
        $this->db->update('dosen',$data);
    }

    public function ambil_beasiswa(){
		$query=$this->db->query("SELECT * from beasiswa");
		return $query;
	}	

	public function edit_beasiswa($where= "") {
		$data = $this->db->query('SELECT * FROM beasiswa '.$where);
		return $data;
	}

	public function update_beasiswa($data){
        $this->db->where('id_beasiswa',$data['id_beasiswa']);
        $this->db->update('beasiswa',$data);
    }

	public function ambil_berita(){
		$query=$this->db->query("SELECT * from berita");
		return $query;
	}

	public function edit_berita($where= "") {
		$data = $this->db->query('SELECT * FROM berita '.$where);
		return $data;
	}

	public function update_berita($data){
        $this->db->where('id_berita',$data['id_berita']);
        $this->db->update('berita',$data);
    }

    public function ambil_profil(){
		$query=$this->db->query("SELECT * from profil");
		return $query;
	}

	public function edit_profil($where= "") {
		$data = $this->db->query('SELECT * FROM profil '.$where);
		return $data;
	}

	public function update_profil($data){
        $this->db->where('id_profil',$data['id_profil']);
        $this->db->update('profil',$data);
    }
}