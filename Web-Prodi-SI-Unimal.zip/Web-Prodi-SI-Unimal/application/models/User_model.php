<?php 
 
class User_model extends CI_Model{	

	function ambil_berita(){
        $sql1 = "select * FROM berita";
        $cari = $this->db->query($sql1);
        if($cari->num_rows()>0)
        {
            foreach($cari->result() as $baris)
            {
                $hasil_berita[]=$baris;
            }
            return $hasil_berita;
        }
    }

    function ambil_galeri(){
        $sql2 = "select * FROM galeri";
        $dapat = $this->db->query($sql2);
        if($dapat->num_rows()>0)
        {
	        foreach ($dapat->result() as $barishasil)
	        {
	           $hasil_galeri[]=$barishasil;
	        }  
	        return $hasil_galeri;  
        }
    }

    function ambil_beasiswa(){
		$sql1 = "select * FROM beasiswa";
        $cari = $this->db->query($sql1);
        if($cari->num_rows()>0)
        {
            foreach($cari->result() as $baris)
            {
                $hasil_beasiswa[]=$baris;
            }
            return $hasil_beasiswa;
        }
	}

	function ambil_dosen(){
		$query=$this->db->query("SELECT dosen.*, mk.`nama` as nama_mk FROM dosen JOIN mk ON dosen.`id_mk` = mk.`id_mk`");
		return $query;
	}

	function ambil_profil(){
        $sql1 = "select * FROM profil";
        $cari = $this->db->query($sql1);
        if($cari->num_rows()>0)
        {
            foreach($cari->result() as $baris)
            {
                $hasil_profil[]=$baris;
            }
            return $hasil_profil;
        }
    }
}