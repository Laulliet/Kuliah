<ul class="nav-menu">
  <li><a href="<?php echo base_url() ?>">Beranda</a></li>
  <li><a href="<?php echo base_url() ?>user/profil">Profil</a></li>
  <li><a href="<?php echo base_url() ?>user/berita">Berita</a></li>
  <li><a href="<?php echo base_url() ?>user/galeri">Galeri</a></li>
  <li><a href="<?php echo base_url() ?>user/kegiatan_mahasiswa">Kegiatan Mahasiswa</a></li>
  <li><a href="<?php echo base_url() ?>user/dosen">Data Dosen</a></li>
  <li><a href="<?php echo base_url() ?>user/beasiswa">Informasi Beasiswa</a></li>         					          		          
  <li><a href="<?php echo base_url() ?>user/mk">Kurikulum</a></li>
  <li><a href="<?php echo base_url() ?>user/alamat">Alamat</a></li>
</ul>