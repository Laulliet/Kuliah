<nav class="navbar navbar-expand-sm navbar-default">
    <div class="navbar-header">
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#main-menu" aria-controls="main-menu" aria-expanded="false" aria-label="Toggle navigation">
            <i class="fa fa-bars"></i>
        </button>
        <a class="navbar-brand" href="./"><img src="<?php echo base_url() ?>images/logounimal.png" alt="Logo" width="50"></a>
        <a class="navbar-brand hidden" href="./"><img src="<?php echo base_url() ?>images/logounimal.png" alt="Logo"></a>
    </div>

    <div id="main-menu" class="main-menu collapse navbar-collapse">
        <ul class="nav navbar-nav">
            <li class="active">
                <a href="<?php echo base_url() ?>admin"> <i class="menu-icon fa fa-dashboard"></i>Dashboard </a>
            </li>
            <li>
                <a href="<?php echo base_url() ?>admin/profil"> <i class="menu-icon fa fa-user"></i>Profil </a>
            </li>
            <li>
                <a href="<?php echo base_url() ?>admin/galeri"> <i class="menu-icon fa fa-id-card-o"></i>Galeri </a>
            </li>
            <li>
                <a href="<?php echo base_url() ?>admin/kegiatan_mahasiswa"> <i class="menu-icon fa fa-bar-chart"></i>Kegiatan Mahasiswa</a>
            </li>
            <li>
                <a href="<?php echo base_url() ?>admin/mk"> <i class="menu-icon fa fa-book"></i>Kurikulum</a>
            </li>
            <li>
                <a href="<?php echo base_url() ?>admin/dosen"> <i class="menu-icon fa fa-users"></i>Data Dosen</a>
            </li>
            <li>
                <a href="<?php echo base_url() ?>admin/beasiswa"> <i class="menu-icon fa fa-users"></i>Informasi Beasiswa</a>
            </li>
            <li>
                <a href="<?php echo base_url() ?>admin/berita"> <i class="menu-icon fa fa-tasks"></i>Berita</a>
            </li>
            <li>
                <a href="<?php echo base_url() ?>login/logout"> <i class="menu-icon fa fa-share"></i>Logout </a>
            </li>
        </ul>
    </div><!-- /.navbar-collapse -->
</nav>