<div class="row">
	<div class="col-lg-6 col-sm-6 col-8 header-top-left no-padding">
		<ul>
			<li></li>
		</ul>			
	</div>
	<div class="col-lg-6 col-sm-6 col-4 header-top-right no-padding">
		<a href="<?php echo base_url() ?>assets_user/tel:+953 012 3654 896">
		<span class="lnr lnr-phone-handset"></span>
		<span class="text">(022)xxxxxxx</span></a>
		<a href="#"><span class="lnr lnr-envelope"></span>
		<span class="text">sisfo@unimal.ac.id</span></a>			
	</div>
</div>			  