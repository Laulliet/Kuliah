<?php 
 
class User extends CI_Controller{
 
	function __construct(){
		parent::__construct();
		$this->load->model('admin_model');
		$this->load->model('user_model');
	}
 
	function index(){
		$cari = $this->user_model->ambil_berita();
		if ($cari)
		{
		    $data['hasil_berita'] = $cari;
		}
		 
		$dpthasil = $this->user_model->ambil_galeri();
		if ($dpthasil)
		{
		    $data['hasil_galeri'] = $dpthasil;
		}
		 
		$this->load->view('user/index', $data); 
	}

	function beasiswa(){
		$cari = $this->user_model->ambil_beasiswa();
		if ($cari)
		{
		    $data['hasil_beasiswa'] = $cari;
		}
		 
		$this->load->view('user/beasiswa', $data); 
	}

	function detail_beasiswa($kode = 0){
	    $row = $this->admin_model->edit_beasiswa("where beasiswa.`id_beasiswa`  = '$kode'")->result_array();

	    $data = array(
	      'id_beasiswa' => $row[0]['id_beasiswa'],
	      'nama' => $row[0]['nama'],
	      'isi' => $row[0]['isi'],
	      'gambar' => $row[0]['gambar'],
	    );

	    $this->load->view('user/detail_beasiswa', $data);
	}

	function dosen(){
		$data = array('data_dosen' => $this->user_model->ambil_dosen()->result_array(),);
		$this->load->view('user/dosen', $data);
	}

	function kegiatan_mahasiswa(){
		$data = array('data_kegiatan_mahasiswa' => $this->admin_model->ambil_kegiatan_mahasiswa()->result_array(),);
		$this->load->view('user/kegiatan_mahasiswa', $data);
	}

	function mk(){
		$data = array('data_mk' => $this->admin_model->ambil_mk()->result_array(),);
		$this->load->view('user/mk', $data);
	}

	function galeri(){
		$dpthasil = $this->user_model->ambil_galeri();
		if ($dpthasil)
		{
		    $data['hasil_galeri'] = $dpthasil;
		}

		$this->load->view('user/galeri', $data);
	}

	function alamat(){
		$this->load->view('user/alamat');
	}

	function berita(){
		$cari = $this->user_model->ambil_berita();
		if ($cari)
		{
		    $data['hasil_berita'] = $cari;
		}
		 
		$this->load->view('user/berita', $data); 
	}

	function detail_berita($kode = 0){
	    $row = $this->admin_model->edit_berita("where berita.`id_berita`  = '$kode'")->result_array();

	    $data = array(
	      'id_berita' => $row[0]['id_berita'],
	      'judul' => $row[0]['judul'],
	      'isi' => $row[0]['isi'],
	      'gambar' => $row[0]['gambar'],
	      'penulis' => $row[0]['penulis'],
	      'tanggal' => $row[0]['tanggal'],
	    );

	    $this->load->view('user/detail_berita', $data);
  	}

  	function profil(){
		$cari = $this->user_model->ambil_profil();
		if ($cari)
		{
		    $data['hasil_profil'] = $cari;
		}
		 
		$this->load->view('user/profil', $data); 
	}

	function detail_profil($kode = 0){
	    $row = $this->admin_model->edit_profil("where profil.`id_profil`  = '$kode'")->result_array();

	    $data = array(
	      'id_profil' => $row[0]['id_profil'],
	      'nama' => $row[0]['nama'],
	      'isi' => $row[0]['isi'],
	      'gambar' => $row[0]['gambar'],
	    );

	    $this->load->view('user/detail_profil', $data);
  	}

}