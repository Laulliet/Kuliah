<?php 
 
class Admin extends CI_Controller{
 
	function __construct(){
		parent::__construct();
	
		if($this->session->userdata('status') != "login"){
			redirect(base_url("login"));
		}
		$this->load->model('admin_model');
		$this->load->library(array('PHPExcel','PHPExcel/IOFactory'));
	}
 
	function index(){
		$this->load->view('admin/dashboard');
	}

	function galeri(){
		$data = array('data_galeri' => $this->admin_model->ambil_galeri()->result_array(),);
		$this->load->view('admin/galeri', $data);
	}

	function tambah_galeri(){
		$this->load->view('admin/tambah_galeri');
	}

	function simpan_galeri(){
        $id_galeri  = '';
        $deskripsi     = $this->input->post('deskripsi');

        //upload file
        $config['max_size']=2048;
        $config['allowed_types']="jpg|jpeg|png";
        $config['remove_spaces']=TRUE;
        $config['overwrite']=TRUE;
        $config['upload_path']=FCPATH.'galeri';

        $this->load->library('upload');
        $this->upload->initialize($config);

        //ambil data image
        $this->upload->do_upload('berkas');
        $data_image = $this->upload->data('file_name');
        $location   = 'galeri/';
        $pict       = $location.$data_image;


        $data=array(
            'id_galeri'=>$id_galeri,
            'berkas'=> $pict,
            'deskripsi'=>$deskripsi
            );
        //simpan data 
        $this->admin_model->simpan('galeri', $data);

        $this->session->set_flashdata("sukses", "
	    	<div class='alert alert-success alert-block'> <a class='close' data-dismiss='alert' href='#'>×</a> <h4 class='alert-heading'>Sukses!</h4> Data Berhasil Diedit
	    	</div>");
        redirect('admin/galeri');
    }

    function edit_galeri($kode = 0){
	    $row = $this->admin_model->edit_galeri("where galeri.`id_galeri`  = '$kode'")->result_array();

	    $data = array(
	      'id_galeri' => $row[0]['id_galeri'],
	      'berkas' => $row[0]['berkas'],
	      'deskripsi' => $row[0]['deskripsi'],
	    );
	    $this->load->view('admin/edit_galeri', $data);
  	}

  	function update_galeri(){

  		//upload file
        $config['max_size']=2048;
        $config['allowed_types']="jpg|jpeg|png";
        $config['remove_spaces']=TRUE;
        $config['overwrite']=TRUE;
        $config['upload_path']=FCPATH.'galeri';

        $this->load->library('upload');
        $this->upload->initialize($config);

        //ambil data image
        $this->upload->do_upload('berkas');
        $data_image = $this->upload->data('file_name');
        $location   = 'galeri/';
        $pict       = $location.$data_image;

	    $data = array(
	      'id_galeri' => $this->input->post('id_galeri'),
	      'berkas' =>$pict,
	      'deskripsi' => $this->input->post('deskripsi'),
	      );

	    $res = $this->admin_model->update_galeri($data);
	    if($res=1){
	      header('location:'.base_url().'admin/galeri');
	      $this->session->set_flashdata("sukses", "
	    	<div class='alert alert-success alert-block'> <a class='close' data-dismiss='alert' href='#'>×</a> <h4 class='alert-heading'>Sukses!</h4> Data Berhasil Diedit
	    	</div>");
	    }
	}

	function hapus_galeri($kode = 0){
	    $result = $this->admin_model->Hapus('galeri',array('id_galeri' => $kode));
	    if($result == 1){
	      header('location:'.base_url().'admin/galeri');
	    $this->session->set_flashdata("sukses", "
	    	<div class='alert alert-success alert-block'> <a class='close' data-dismiss='alert' href='#'>×</a> <h4 class='alert-heading'>Sukses!</h4> Data Berhasil Dihapus
	    	</div>");
		}
	}

	function kegiatan_mahasiswa(){
		$data = array('data_kegiatan_mahasiswa' => $this->admin_model->ambil_kegiatan_mahasiswa()->result_array(),);
		$this->load->view('admin/kegiatan_mahasiswa', $data);
	}

	function tambah_kegiatan_mahasiswa(){
		$this->load->view('admin/tambah_kegiatan_mahasiswa');
	}

	function simpan_kegiatan_mahasiswa(){
	    $id_kegiatan_mahasiswa	= '';
	    $nama= $_POST['nama']; 
	    $deskripsi= $_POST['deskripsi'];

	    $data = array(  
	      'id'=> $id_kegiatan_mahasiswa,
	      'nama'=> $nama,
	      'deskripsi'=> $deskripsi,
	      );

	    $this->admin_model->simpan('kegiatan_mahasiswa', $data);
	    $this->session->set_flashdata("sukses", "
	    	<div class='alert alert-success alert-block'> <a class='close' data-dismiss='alert' href='#'>×</a> <h4 class='alert-heading'>Sukses!</h4> Data Berhasil Ditambahkan
	    	</div>");
	    redirect('admin/kegiatan_mahasiswa');
  	}

  	function edit_kegiatan_mahasiswa($kode = 0){
	    $row = $this->admin_model->edit_kegiatan_mahasiswa("where kegiatan_mahasiswa.`id`  = '$kode'")->result_array();

	    $data = array(
	      'id' => $row[0]['id'],
	      'nama' => $row[0]['nama'],
	      'deskripsi' => $row[0]['deskripsi'],
	    );
	    $this->load->view('admin/edit_kegiatan_mahasiswa', $data);
  	}

  	function update_kegiatan_mahasiswa(){
	    $data = array(
	      'id' => $this->input->post('id'),
	      'nama' => $this->input->post('nama'),
	      'deskripsi' => $this->input->post('deskripsi'),
	      );

	    $res = $this->admin_model->update_kegiatan_mahasiswa($data);
	    if($res=1){
	      header('location:'.base_url().'admin/kegiatan_mahasiswa');
	      $this->session->set_flashdata("sukses", "
	    	<div class='alert alert-success alert-block'> <a class='close' data-dismiss='alert' href='#'>×</a> <h4 class='alert-heading'>Sukses!</h4> Data Berhasil Diedit
	    	</div>");
	    }
	}

	function hapus_kegiatan_mahasiswa($kode = 0){
	    $result = $this->admin_model->Hapus('kegiatan_mahasiswa',array('id' => $kode));
	    if($result == 1){
	      header('location:'.base_url().'admin/kegiatan_mahasiswa');
	    $this->session->set_flashdata("sukses", "
	    	<div class='alert alert-success alert-block'> <a class='close' data-dismiss='alert' href='#'>×</a> <h4 class='alert-heading'>Sukses!</h4> Data Berhasil Dihapus
	    	</div>");
		}
	}

	function mk(){
		$data = array('data_mk' => $this->admin_model->ambil_mk()->result_array(),);
		$this->load->view('admin/mk', $data);
	}

	function tambah_mk(){
		$this->load->view('admin/tambah_mk');
	}

	function simpan_mk(){
	    $id_mk	= '';
	    $mk= $_POST['mk']; 

	    $data = array(  
	      'id_mk'=> $id_mk,
	      'nama'=> $mk,
	      );

	    $this->admin_model->simpan('mk', $data);
	    $this->session->set_flashdata("sukses", "
	    	<div class='alert alert-success alert-block'> <a class='close' data-dismiss='alert' href='#'>×</a> <h4 class='alert-heading'>Sukses!</h4> Data Berhasil Ditambahkan
	    	</div>");
	    redirect('admin/mk');
  	}

  	function edit_mk($kode = 0){
	    $row = $this->admin_model->edit_mk("where mk.`id_mk`  = '$kode'")->result_array();

	    $data = array(
	      'id_mk' => $row[0]['id_mk'],
	      'nama' => $row[0]['nama'],
	    );
	    $this->load->view('admin/edit_mk', $data);
  	}

  	function update_mk(){
	    $data = array(
	      'id_mk' => $this->input->post('id_mk'),
	      'nama' => $this->input->post('nama'),
	      );

	    $res = $this->admin_model->update_mk($data);
	    if($res=1){
	      header('location:'.base_url().'admin/mk');
	      $this->session->set_flashdata("sukses", "
	    	<div class='alert alert-success alert-block'> <a class='close' data-dismiss='alert' href='#'>×</a> <h4 class='alert-heading'>Sukses!</h4> Data Berhasil Diedit
	    	</div>");
	    }
	}

	function hapus_mk($kode = 0){
	    $result = $this->admin_model->Hapus('mk',array('id_mk' => $kode));
	    if($result == 1){
	      header('location:'.base_url().'admin/mk');
	    $this->session->set_flashdata("sukses", "
	    	<div class='alert alert-success alert-block'> <a class='close' data-dismiss='alert' href='#'>×</a> <h4 class='alert-heading'>Sukses!</h4> Data Berhasil Dihapus
	    	</div>");
		}
	}

	function dosen(){
		$data = array('data_dosen' => $this->admin_model->ambil_dosen()->result_array(),);
		$this->load->view('admin/dosen', $data);
	}

	function tambah_dosen(){
		$data = array('data_mk' => $this->admin_model->ambil_mk()->result_array(),);
		$this->load->view('admin/tambah_dosen', $data);
	}

	function simpan_dosen(){
	    $id_dosen	= '';
	    $nip= $_POST['nip']; 
	    $nama= $_POST['nama']; 
	    $jenis_kelamin= $_POST['jenis_kelamin']; 
	    $umur= $_POST['umur']; 
	    $alamat= $_POST['alamat'];
	    $id_mk= $_POST['mk']; 

	    $data = array(  
	      'id_dosen'=> $id_dosen,
	      'nip'=> $nip,
	      'nama'=> $nama,
	      'jenis_kelamin'=> $jenis_kelamin,
	      'umur'=> $umur,
	      'alamat'=> $alamat,
	      'id_mk'=> $id_mk,
	      );

	    $this->admin_model->simpan('dosen', $data);
	    $this->session->set_flashdata("sukses", "
	    	<div class='alert alert-success alert-block'> <a class='close' data-dismiss='alert' href='#'>×</a> <h4 class='alert-heading'>Sukses!</h4> Data Berhasil Ditambahkan
	    	</div>");
	    redirect('admin/dosen');
  	}

  	function hapus_dosen($kode = 0){
	    $result = $this->admin_model->Hapus('dosen',array('id_dosen' => $kode));
	    if($result == 1){
	      header('location:'.base_url().'admin/dosen');
	    $this->session->set_flashdata("sukses", "
	    	<div class='alert alert-success alert-block'> <a class='close' data-dismiss='alert' href='#'>×</a> <h4 class='alert-heading'>Sukses!</h4> Data Berhasil Dihapus
	    	</div>");
		}
	}

	function edit_dosen($kode = 0){
	    $row = $this->admin_model->edit_dosen("where dosen.`id_dosen`  = '$kode'")->result_array();

	    $data = array(
	      'id_dosen' => $row[0]['id_dosen'],
	      'nip' => $row[0]['nip'],
	      'nama' => $row[0]['nama'],
	      'jenis_kelamin' => $row[0]['jenis_kelamin'],
	      'umur' => $row[0]['umur'],
	      'alamat' => $row[0]['alamat'],
	      'id_mk' => $row[0]['id_mk'],
	    );

	    $this->load->view('admin/edit_dosen', $data);
  	}

  	function update_dosen(){
	    $data = array(
	      'id_dosen' => $this->input->post('id_dosen'),
	      'nip' => $this->input->post('nip'),
	      'nama' => $this->input->post('nama'),
	      'jenis_kelamin' => $this->input->post('jenis_kelamin'),
	      'umur' => $this->input->post('umur'),
	      'alamat' => $this->input->post('alamat'),
	      'id_mk' => $this->input->post('id_mk'),
	      );

	    $res = $this->admin_model->update_dosen($data);
	    if($res=1){
	      header('location:'.base_url().'admin/dosen');
	      $this->session->set_flashdata("sukses", "
	    	<div class='alert alert-success alert-block'> <a class='close' data-dismiss='alert' href='#'>×</a> <h4 class='alert-heading'>Sukses!</h4> Data Berhasil Diedit
	    	</div>");
	    }
	}

	function beasiswa(){
		$data = array('data_beasiswa' => $this->admin_model->ambil_beasiswa()->result_array(),);
		$this->load->view('admin/beasiswa', $data);
	}

	function tambah_beasiswa(){
		$this->load->view('admin/tambah_beasiswa');
	}

	function detail_beasiswa($kode = 0){
	    $row = $this->admin_model->edit_beasiswa("where beasiswa.`id_beasiswa`  = '$kode'")->result_array();

	    $data = array(
	      'id_beasiswa' => $row[0]['id_beasiswa'],
	      'nama' => $row[0]['nama'],
	      'isi' => $row[0]['isi'],
	      'gambar' => $row[0]['gambar'],
	    );

	    $this->load->view('admin/detail_beasiswa', $data);
  	}

  	function simpan_beasiswa(){
        $id_beasiswa  = '';
        $judul     = $this->input->post('judul');
        $isi     = $this->input->post('isi');

        //upload file
        $config['max_size']=2048;
        $config['allowed_types']="jpg|jpeg|png";
        $config['remove_spaces']=TRUE;
        $config['overwrite']=TRUE;
        $config['upload_path']=FCPATH.'beasiswa';

        $this->load->library('upload');
        $this->upload->initialize($config);

        //ambil data image
        $this->upload->do_upload('gambar');
        $data_image = $this->upload->data('file_name');
        $location   = 'beasiswa/';
        $pict       = $location.$data_image;


        $data=array(
            'id_beasiswa'=>$id_beasiswa,
            'nama'=>$judul,
            'isi'=>$isi,
            'gambar'=> $pict
            );
        //simpan data 
        $this->admin_model->simpan('beasiswa', $data);

        $this->session->set_flashdata("sukses", "
	    	<div class='alert alert-success alert-block'> <a class='close' data-dismiss='alert' href='#'>×</a> <h4 class='alert-heading'>Sukses!</h4> Data Berhasil Diedit
	    	</div>");
        redirect('admin/beasiswa');
    }

    function hapus_beasiswa($kode = 0){
	    $result = $this->admin_model->Hapus('beasiswa',array('id_beasiswa' => $kode));
	    if($result == 1){
	      header('location:'.base_url().'admin/beasiswa');
	    $this->session->set_flashdata("sukses", "
	    	<div class='alert alert-success alert-block'> <a class='close' data-dismiss='alert' href='#'>×</a> <h4 class='alert-heading'>Sukses!</h4> Data Berhasil Dihapus
	    	</div>");
		}
	}

	function edit_beasiswa($kode = 0){
	    $row = $this->admin_model->edit_beasiswa("where beasiswa.`id_beasiswa`  = '$kode'")->result_array();

	    $data = array(
	      'id_beasiswa' => $row[0]['id_beasiswa'],
	      'nama' => $row[0]['nama'],
	      'isi' => $row[0]['isi'],
	      'gambar' => $row[0]['gambar'],
	    );

	    $this->load->view('admin/edit_beasiswa', $data);
  	}

  	function update_beasiswa(){
  		$tanggal =  date('Y-m-d');

  		 //upload file
        $config['max_size']=2048;
        $config['allowed_types']="jpg|jpeg|png";
        $config['remove_spaces']=TRUE;
        $config['overwrite']=TRUE;
        $config['upload_path']=FCPATH.'beasiswa';

        $this->load->library('upload');
        $this->upload->initialize($config);

        //ambil data image
        $this->upload->do_upload('gambar');
        $data_image = $this->upload->data('file_name');
        $location   = 'beasiswa/';
        $pict       = $location.$data_image;

	    $data = array(
	      'id_beasiswa' => $this->input->post('id_beasiswa'),
	      'nama' => $this->input->post('judul'),
	      'isi' => $this->input->post('isi'),
	      'gambar' => $pict,
	      );

	    $res = $this->admin_model->update_beasiswa($data);
	    if($res=1){
	      header('location:'.base_url().'admin/beasiswa');
	      $this->session->set_flashdata("sukses", "
	    	<div class='alert alert-success alert-block'> <a class='close' data-dismiss='alert' href='#'>×</a> <h4 class='alert-heading'>Sukses!</h4> Data Berhasil Diedit
	    	</div>");
	    }
	}

	function berita(){
		$data = array('data_berita' => $this->admin_model->ambil_berita()->result_array(),);
		$this->load->view('admin/berita', $data);
	}

	function tambah_berita(){
		$this->load->view('admin/tambah_berita');
	}

	function detail_berita($kode = 0){
	    $row = $this->admin_model->edit_berita("where berita.`id_berita`  = '$kode'")->result_array();

	    $data = array(
	      'id_berita' => $row[0]['id_berita'],
	      'judul' => $row[0]['judul'],
	      'isi' => $row[0]['isi'],
	      'gambar' => $row[0]['gambar'],
	      'penulis' => $row[0]['penulis'],
	      'tanggal' => $row[0]['tanggal'],
	    );

	    $this->load->view('admin/detail_berita', $data);
  	}

  	function simpan_berita(){
        $id_berita  = '';
        $judul     = $this->input->post('judul');
        $isi     = $this->input->post('isi');
        $penulis     = $this->input->post('penulis');
		$tanggal =  date('Y-m-d');

        //upload file
        $config['max_size']=2048;
        $config['allowed_types']="jpg|jpeg|png";
        $config['remove_spaces']=TRUE;
        $config['overwrite']=TRUE;
        $config['upload_path']=FCPATH.'berita';

        $this->load->library('upload');
        $this->upload->initialize($config);

        //ambil data image
        $this->upload->do_upload('gambar');
        $data_image = $this->upload->data('file_name');
        $location   = 'berita/';
        $pict       = $location.$data_image;


        $data=array(
            'id_berita'=>$id_berita,
            'judul'=>$judul,
            'isi'=>$isi,
            'gambar'=> $pict,
            'penulis'=>$penulis,
            'tanggal'=>$tanggal
            );
        //simpan data 
        $this->admin_model->simpan('berita', $data);

        $this->session->set_flashdata("sukses", "
	    	<div class='alert alert-success alert-block'> <a class='close' data-dismiss='alert' href='#'>×</a> <h4 class='alert-heading'>Sukses!</h4> Data Berhasil Diedit
	    	</div>");
        redirect('admin/berita');
    }

    function hapus_berita($kode = 0){
	    $result = $this->admin_model->Hapus('berita',array('id_berita' => $kode));
	    if($result == 1){
	      header('location:'.base_url().'admin/berita');
	    $this->session->set_flashdata("sukses", "
	    	<div class='alert alert-success alert-block'> <a class='close' data-dismiss='alert' href='#'>×</a> <h4 class='alert-heading'>Sukses!</h4> Data Berhasil Dihapus
	    	</div>");
		}
	}

	function edit_berita($kode = 0){
	    $row = $this->admin_model->edit_berita("where berita.`id_berita`  = '$kode'")->result_array();

	    $data = array(
	      'id_berita' => $row[0]['id_berita'],
	      'judul' => $row[0]['judul'],
	      'isi' => $row[0]['isi'],
	      'gambar' => $row[0]['gambar'],
	      'penulis' => $row[0]['penulis'],
	      'tanggal' => $row[0]['tanggal'],
	    );

	    $this->load->view('admin/edit_berita', $data);
  	}

  	function update_berita(){
  		$tanggal =  date('Y-m-d');

  		 //upload file
        $config['max_size']=2048;
        $config['allowed_types']="jpg|jpeg|png";
        $config['remove_spaces']=TRUE;
        $config['overwrite']=TRUE;
        $config['upload_path']=FCPATH.'berita';

        $this->load->library('upload');
        $this->upload->initialize($config);

        //ambil data image
        $this->upload->do_upload('gambar');
        $data_image = $this->upload->data('file_name');
        $location   = 'berita/';
        $pict       = $location.$data_image;

	    $data = array(
	      'id_berita' => $this->input->post('id_berita'),
	      'judul' => $this->input->post('judul'),
	      'isi' => $this->input->post('isi'),
	      'gambar' => $pict,
	      'penulis' => $this->input->post('penulis'),
	      'tanggal' => $tanggal,
	      );

	    $res = $this->admin_model->update_berita($data);
	    if($res=1){
	      header('location:'.base_url().'admin/berita');
	      $this->session->set_flashdata("sukses", "
	    	<div class='alert alert-success alert-block'> <a class='close' data-dismiss='alert' href='#'>×</a> <h4 class='alert-heading'>Sukses!</h4> Data Berhasil Diedit
	    	</div>");
	    }
	}

	function profil(){
		$data = array('data_profil' => $this->admin_model->ambil_profil()->result_array(),);
		$this->load->view('admin/profil', $data);
	}

	function tambah_profil(){
		$this->load->view('admin/tambah_profil');
	}

	function detail_profil($kode = 0){
	    $row = $this->admin_model->edit_profil("where profil.`id_profil`  = '$kode'")->result_array();

	    $data = array(
	      'id_profil' => $row[0]['id_profil'],
	      'nama' => $row[0]['nama'],
	      'isi' => $row[0]['isi'],
	      'gambar' => $row[0]['gambar'],
	    );

	    $this->load->view('admin/detail_profil', $data);
  	}

  	function simpan_profil(){
        $id_profil  = '';
        $judul     = $this->input->post('judul');
        $isi     = $this->input->post('isi');

        //upload file
        $config['max_size']=2048;
        $config['allowed_types']="jpg|jpeg|png";
        $config['remove_spaces']=TRUE;
        $config['overwrite']=TRUE;
        $config['upload_path']=FCPATH.'profil';

        $this->load->library('upload');
        $this->upload->initialize($config);

        //ambil data image
        $this->upload->do_upload('gambar');
        $data_image = $this->upload->data('file_name');
        $location   = 'profil/';
        $pict       = $location.$data_image;


        $data=array(
            'id_profil'=>$id_profil,
            'nama'=>$judul,
            'isi'=>$isi,
            'gambar'=> $pict
            );
        //simpan data 
        $this->admin_model->simpan('profil', $data);

        $this->session->set_flashdata("sukses", "
	    	<div class='alert alert-success alert-block'> <a class='close' data-dismiss='alert' href='#'>×</a> <h4 class='alert-heading'>Sukses!</h4> Data Berhasil Diedit
	    	</div>");
        redirect('admin/profil');
    }

    function hapus_profil($kode = 0){
	    $result = $this->admin_model->Hapus('profil',array('id_profil' => $kode));
	    if($result == 1){
	      header('location:'.base_url().'admin/profil');
	    $this->session->set_flashdata("sukses", "
	    	<div class='alert alert-success alert-block'> <a class='close' data-dismiss='alert' href='#'>×</a> <h4 class='alert-heading'>Sukses!</h4> Data Berhasil Dihapus
	    	</div>");
		}
	}

	function edit_profil($kode = 0){
	    $row = $this->admin_model->edit_profil("where profil.`id_profil`  = '$kode'")->result_array();

	    $data = array(
	      'id_profil' => $row[0]['id_profil'],
	      'nama' => $row[0]['nama'],
	      'isi' => $row[0]['isi'],
	      'gambar' => $row[0]['gambar'],
	    );

	    $this->load->view('admin/edit_profil', $data);
  	}

  	function update_profil(){
  		$tanggal =  date('Y-m-d');

  		 //upload file
        $config['max_size']=2048;
        $config['allowed_types']="jpg|jpeg|png";
        $config['remove_spaces']=TRUE;
        $config['overwrite']=TRUE;
        $config['upload_path']=FCPATH.'profil';

        $this->load->library('upload');
        $this->upload->initialize($config);

        //ambil data image
        $this->upload->do_upload('gambar');
        $data_image = $this->upload->data('file_name');
        $location   = 'profil/';
        $pict       = $location.$data_image;

	    $data = array(
	      'id_profil' => $this->input->post('id_profil'),
	      'nama' => $this->input->post('judul'),
	      'isi' => $this->input->post('isi'),
	      'gambar' => $pict,
	      );

	    $res = $this->admin_model->update_profil($data);
	    if($res=1){
	      header('location:'.base_url().'admin/profil');
	      $this->session->set_flashdata("sukses", "
	    	<div class='alert alert-success alert-block'> <a class='close' data-dismiss='alert' href='#'>×</a> <h4 class='alert-heading'>Sukses!</h4> Data Berhasil Diedit
	    	</div>");
	    }
	}
}